import React, { useState, useMemo } from 'react';
import { Plus, Trash2, Calculator, Save, RefreshCw, AlertCircle, CheckCircle2, Ruler } from 'lucide-react';

// 水準測量等級標準 (mm)
const STANDARDS = {
  first_class: { name: '一等水準 (±4√K)', factor: 4 },
  second_class: { name: '二等水準 (±8√K)', factor: 8 },
  ordinary: { name: '普通水準 (±12√K)', factor: 12 },
  construction: { name: '施工水準 (±20√K)', factor: 20 },
};

const App = () => {
  // --- 狀態管理 ---
  const [config, setConfig] = useState({
    startElev: 100.000,
    endElev: 100.000,
    type: 'loop', // 'loop' (閉合) or 'open' (附合)
    standard: 'ordinary'
  });

  // 更新 Rows 結構：分開 bsDist (後視距離) 和 fsDist (前視距離)
  const [rows, setRows] = useState([
    { id: 1, name: 'BM-A', bs: '', bsDist: '', fs: '', fsDist: '', adjElev: null },
    { id: 2, name: 'TP-1', bs: '', bsDist: '', fs: '', fsDist: '', adjElev: null },
    { id: 3, name: 'TP-2', bs: '', bsDist: '', fs: '', fsDist: '', adjElev: null },
    { id: 4, name: 'BM-A', bs: '', bsDist: '', fs: '', fsDist: '', adjElev: null }
  ]);

  const [showAdjusted, setShowAdjusted] = useState(false);

  // --- 核心計算邏輯 ---
  const calculationResult = useMemo(() => {
    let currentElev = parseFloat(config.startElev) || 0;
    let sumBS = 0;
    let sumFS = 0;
    let sumBSDist = 0; // 總後視距離
    let sumFSDist = 0; // 總前視距離
    let currentHI = 0;

    // 1. 逐行計算 HI 和 Elev
    const calculatedRows = rows.map((row, index) => {
      const bs = parseFloat(row.bs);
      const fs = parseFloat(row.fs);
      const bsDist = parseFloat(row.bsDist) || 0;
      const fsDist = parseFloat(row.fsDist) || 0;
      
      let calculatedElev = null;
      let calculatedHI = null;

      // 計算高程 (Elev)
      if (index === 0) {
        calculatedElev = currentElev;
      } else {
        if (!isNaN(fs)) {
          calculatedElev = currentHI - fs;
          currentElev = calculatedElev; // 更新當前高程供下一點使用
          sumFS += fs;
          sumFSDist += fsDist;
        }
      }

      // 計算儀器高 (HI)
      if (!isNaN(bs)) {
        const baseElev = (calculatedElev !== null) ? calculatedElev : 0;
        calculatedHI = baseElev + bs;
        currentHI = calculatedHI;
        sumBS += bs;
        sumBSDist += bsDist;
      }

      return {
        ...row,
        hi: calculatedHI,
        elev: calculatedElev
      };
    });

    // 2. 統計數據
    const totalDist = sumBSDist + sumFSDist; // 總距離 = 所有後視距 + 所有前視距
    const distBalance = sumBSDist - sumFSDist; // 視距差 (檢核視距平衡用)

    // 3. 精度檢核
    const K = totalDist / 1000; // 公里
    const standardFactor = STANDARDS[config.standard].factor;
    const allowableError = K > 0 ? standardFactor * Math.sqrt(K) : 0;

    // 理論閉合差
    let theoryDiff = 0;
    if (config.type === 'loop') {
      theoryDiff = 0; 
    } else {
      theoryDiff = (parseFloat(config.endElev) || 0) - (parseFloat(config.startElev) || 0);
    }

    const measuredDiff = sumBS - sumFS;
    const misclosureM = measuredDiff - theoryDiff; 
    const misclosureMM = Math.round(misclosureM * 1000); 

    return {
      data: calculatedRows,
      stats: {
        sumBS,
        sumFS,
        sumBSDist,
        sumFSDist,
        totalDist,
        distBalance,
        misclosure: misclosureMM,
        allowable: parseFloat(allowableError.toFixed(1)),
        isPass: Math.abs(misclosureMM) <= allowableError || totalDist === 0
      }
    };

  }, [config, rows]);

  const { data: calculatedData, stats } = calculationResult;

  // --- 事件處理 ---

  const handleInputChange = (index, field, value) => {
    const newRows = [...rows];
    newRows[index][field] = value;
    newRows.forEach(r => r.adjElev = null); 
    setRows(newRows);
    setShowAdjusted(false);
  };

  const addRow = () => {
    setRows([...rows, { id: Date.now(), name: `TP-${rows.length}`, bs: '', bsDist: '', fs: '', fsDist: '', adjElev: null }]);
    setShowAdjusted(false);
  };

  const deleteRow = (index) => {
    if (rows.length <= 2) {
      alert("至少需要保留起始點和終點！");
      return;
    }
    const newRows = rows.filter((_, i) => i !== index);
    setRows(newRows);
    setShowAdjusted(false);
  };

  const performAdjustment = () => {
    if (!stats.isPass && stats.totalDist > 0) {
      if(!confirm("閉合差超限，確定要強行平差嗎？")) return;
    }

    const count = rows.length - 1; 
    if (count <= 0) return;

    const correctionPerSection = (stats.misclosure * -1) / count; 
    
    let currentCorrection = 0;
    
    const newRows = calculatedData.map((row, index) => {
      const { hi, elev, ...originalRowData } = row;

      if (index === 0) {
        return { ...originalRowData, adjElev: row.elev }; 
      }
      
      currentCorrection += correctionPerSection;
      const originalElev = row.elev || 0;
      const adjVal = originalElev + (currentCorrection / 1000); 
      
      return { ...originalRowData, adjElev: adjVal };
    });

    setRows(newRows);
    setShowAdjusted(true);
  };

  const resetAll = () => {
    if(confirm("確定要重置所有數據嗎？")) {
       window.location.reload();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-2 md:p-8 font-sans text-slate-800">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div>
            <h1 className="text-2xl font-bold text-blue-600 flex items-center gap-2">
              <Calculator className="w-8 h-8" />
              工程水準測量計算器
            </h1>
            <p className="text-slate-500 text-sm mt-1">自動計算高程、視距平衡檢核與精度分析</p>
          </div>
          <div className="flex gap-2 mt-4 md:mt-0">
             <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm font-medium transition">
                <Save className="w-4 h-4" /> 列印/存檔
             </button>
             <button onClick={resetAll} className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm font-medium transition">
                <RefreshCw className="w-4 h-4" /> 重置
             </button>
          </div>
        </header>

        {/* Settings Panel */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">已知起始高程 (m)</label>
             <input 
               type="number" 
               step="0.001"
               value={config.startElev}
               onChange={(e) => { setConfig({...config, startElev: e.target.value}); setShowAdjusted(false); }}
               className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
             />
           </div>
           
           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">測量類型</label>
             <select 
               value={config.type}
               onChange={(e) => { setConfig({...config, type: e.target.value}); setShowAdjusted(false); }}
               className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
             >
               <option value="loop">閉合水準 (回到起點)</option>
               <option value="open">附合水準 (到已知終點)</option>
             </select>
           </div>

           {config.type === 'open' && (
             <div className="space-y-1">
               <label className="text-xs font-bold text-slate-500 uppercase">已知終點高程 (m)</label>
               <input 
                 type="number" 
                 step="0.001"
                 value={config.endElev}
                 onChange={(e) => { setConfig({...config, endElev: e.target.value}); setShowAdjusted(false); }}
                 className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
               />
             </div>
           )}

           <div className="space-y-1">
             <label className="text-xs font-bold text-slate-500 uppercase">精度標準</label>
             <select 
               value={config.standard}
               onChange={(e) => { setConfig({...config, standard: e.target.value}); setShowAdjusted(false); }}
               className="w-full p-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
             >
               {Object.entries(STANDARDS).map(([key, val]) => (
                 <option key={key} value={key}>{val.name}</option>
               ))}
             </select>
           </div>
        </div>

        {/* Main Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-slate-200">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase">
                <tr>
                  <th className="p-4 w-12 text-center">#</th>
                  <th className="p-4 min-w-[100px]">點號</th>
                  <th className="p-4 min-w-[120px] bg-blue-50/50 text-blue-800">
                    <div className="flex flex-col">
                      <span>後視 BS (+)</span>
                      <span className="text-[10px] text-blue-400 font-normal">讀數</span>
                    </div>
                  </th>
                  <th className="p-4 min-w-[100px] bg-blue-50/50 text-blue-800">
                    <div className="flex flex-col">
                      <span>後視距離</span>
                      <span className="text-[10px] text-blue-400 font-normal">m</span>
                    </div>
                  </th>
                  <th className="p-4 min-w-[120px] bg-red-50/50 text-red-800">
                    <div className="flex flex-col">
                      <span>前視 FS (-)</span>
                      <span className="text-[10px] text-red-400 font-normal">讀數</span>
                    </div>
                  </th>
                  <th className="p-4 min-w-[100px] bg-red-50/50 text-red-800">
                     <div className="flex flex-col">
                      <span>前視距離</span>
                      <span className="text-[10px] text-red-400 font-normal">m</span>
                    </div>
                  </th>
                  <th className="p-4 min-w-[100px] bg-slate-100/50">儀器高 HI</th>
                  <th className="p-4 min-w-[100px] bg-green-50/50 text-green-800">計算高程</th>
                  {showAdjusted && <th className="p-4 min-w-[100px] bg-yellow-50/50 text-yellow-700">平差高程</th>}
                  <th className="p-4 w-12 text-center">刪除</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {calculatedData.map((row, index) => {
                  const isLastRow = index === rows.length - 1;
                  const isFirstRow = index === 0;

                  return (
                  <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-4 text-center text-slate-400">{index + 1}</td>
                    <td className="p-4">
                      <input 
                        type="text" 
                        value={row.name}
                        onChange={(e) => handleInputChange(index, 'name', e.target.value)}
                        className="w-full bg-transparent font-medium focus:outline-none focus:border-b-2 focus:border-blue-500"
                      />
                    </td>
                    
                    {/* BS Group */}
                    <td className="p-4 bg-blue-50/20">
                      {!isLastRow && (
                        <input 
                          type="number" 
                          step="0.001"
                          placeholder="BS"
                          value={row.bs}
                          onChange={(e) => handleInputChange(index, 'bs', e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none text-right font-mono"
                        />
                      )}
                    </td>
                    <td className="p-4 bg-blue-50/20 border-r border-slate-100">
                      {!isLastRow && (
                        <input 
                          type="number" 
                          step="0.1"
                          placeholder="dist"
                          value={row.bsDist}
                          onChange={(e) => handleInputChange(index, 'bsDist', e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded focus:ring-2 focus:ring-blue-500 focus:outline-none text-right font-mono text-sm text-slate-600"
                        />
                      )}
                    </td>

                    {/* FS Group */}
                    <td className="p-4 bg-red-50/20">
                      {!isFirstRow && (
                        <input 
                          type="number" 
                          step="0.001" 
                          placeholder="FS"
                          value={row.fs}
                          onChange={(e) => handleInputChange(index, 'fs', e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none text-right font-mono"
                        />
                      )}
                    </td>
                    <td className="p-4 bg-red-50/20 border-r border-slate-100">
                      {!isFirstRow && (
                        <input 
                          type="number" 
                          step="0.1" 
                          placeholder="dist"
                          value={row.fsDist}
                          onChange={(e) => handleInputChange(index, 'fsDist', e.target.value)}
                          className="w-full p-2 bg-white border border-slate-200 rounded focus:ring-2 focus:ring-red-500 focus:outline-none text-right font-mono text-sm text-slate-600"
                        />
                      )}
                    </td>

                    <td className="p-4 bg-slate-100/30 text-slate-600 font-mono text-right">
                      {row.hi !== null ? row.hi.toFixed(3) : '-'}
                    </td>
                    <td className="p-4 bg-green-50/30 font-bold text-slate-700 font-mono text-right">
                      {row.elev !== null ? row.elev.toFixed(3) : '-'}
                    </td>
                    {showAdjusted && (
                       <td className="p-4 bg-yellow-50/30 font-bold text-yellow-700 font-mono text-right">
                         {row.adjElev ? row.adjElev.toFixed(3) : '-'}
                       </td>
                    )}
                    <td className="p-4 text-center">
                      <button 
                        onClick={() => deleteRow(index)}
                        disabled={rows.length <= 2}
                        className="text-slate-400 hover:text-red-500 disabled:opacity-30 transition"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="p-4 bg-slate-50 border-t border-slate-200">
            <button 
              onClick={addRow}
              className="w-full py-3 border-2 border-dashed border-slate-300 rounded-lg text-slate-500 hover:border-blue-500 hover:text-blue-500 hover:bg-blue-50 transition flex items-center justify-center gap-2 font-medium"
            >
              <Plus className="w-5 h-5" /> 新增測點 (TP)
            </button>
          </div>
        </div>

        {/* Results Dashboard */}
        <div className={`rounded-2xl shadow-lg p-6 text-white transition-colors duration-500 ${stats.isPass ? 'bg-gradient-to-br from-green-600 to-teal-700' : 'bg-gradient-to-br from-red-500 to-pink-700'}`}>
          <div className="flex flex-col lg:flex-row justify-between gap-6">
            
            {/* Left: Stats */}
            <div className="flex-1 space-y-4">
              <h3 className="text-xl font-bold flex items-center gap-2 opacity-90">
                {stats.isPass ? <CheckCircle2 /> : <AlertCircle />}
                測量結果判定：{stats.isPass ? '合格 (PASS)' : '不合格 (FAIL)'}
              </h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm opacity-90">
                <div className="bg-white/20 p-3 rounded-lg col-span-2 md:col-span-1">
                  <span className="block text-xs uppercase opacity-70">閉合差 (Misclosure)</span>
                  <span className="text-2xl font-mono font-bold">{stats.misclosure > 0 ? `+${stats.misclosure}` : stats.misclosure} mm</span>
                </div>
                <div className="bg-white/20 p-3 rounded-lg col-span-2 md:col-span-1">
                  <span className="block text-xs uppercase opacity-70">容許誤差 (Allowable)</span>
                  <span className="text-2xl font-mono font-bold">±{stats.allowable} mm</span>
                </div>
                
                {/* 距離統計區 */}
                <div className="bg-white/10 p-3 rounded-lg border border-white/10">
                   <div className="flex items-center gap-1 mb-1">
                      <Ruler className="w-3 h-3" />
                      <span className="text-xs uppercase opacity-70">總距離</span>
                   </div>
                   <div className="font-mono font-bold text-lg">{stats.totalDist.toFixed(1)} m</div>
                   <div className="text-xs opacity-60">{rows.length} 站</div>
                </div>

                <div className={`p-3 rounded-lg border border-white/10 ${Math.abs(stats.distBalance) > 5 ? 'bg-red-500/30' : 'bg-white/10'}`}>
                   <div className="flex items-center gap-1 mb-1">
                      <span className="text-xs uppercase opacity-70">前後視距差</span>
                   </div>
                   <div className="font-mono font-bold text-lg">{stats.distBalance > 0 ? '+' : ''}{stats.distBalance.toFixed(1)} m</div>
                   <div className="text-xs opacity-60">ΣBS距: {stats.sumBSDist.toFixed(1)} | ΣFS距: {stats.sumFSDist.toFixed(1)}</div>
                </div>
              </div>

              <div className="flex gap-4 text-xs opacity-80 pt-2 border-t border-white/10">
                 <div>Σ BS 讀數: {stats.sumBS.toFixed(3)} m</div>
                 <div>Σ FS 讀數: {stats.sumFS.toFixed(3)} m</div>
                 <div>檢核: {(stats.sumBS - stats.sumFS).toFixed(3)} m</div>
              </div>
            </div>

            {/* Right: Actions */}
            <div className="flex flex-col justify-center items-end gap-3 border-l border-white/20 pl-6 min-w-[200px]">
               <button 
                 onClick={performAdjustment}
                 disabled={showAdjusted}
                 className="w-full px-6 py-3 bg-white text-slate-800 font-bold rounded-lg shadow hover:bg-yellow-50 disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center justify-center gap-2"
               >
                 <Calculator className="w-4 h-4" />
                 {showAdjusted ? '已完成平差' : '執行簡易平差'}
               </button>
               {showAdjusted && (
                 <p className="text-xs text-yellow-200 mt-1 text-center w-full">* 採用按站數平均分配法</p>
               )}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};

export default App;